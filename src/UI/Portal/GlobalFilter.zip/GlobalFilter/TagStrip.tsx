import { GlobalFilterService } from "./GlobalFilterService";
import { AdditionalFilter } from "./FilterStore";


export class TagStrip {
    constructor() {
    }

    async switchApplication(id: string) {
        await GlobalFilterService.switchApplication(id);
    }

    async addAdditionalFilter(filterType: string, filterValue: string, isNegated = false, pjaxReload = true) {
        await GlobalFilterService.addAdditionalFilter(filterType, filterValue, isNegated, pjaxReload);
        GlobalFilterService.shouldShowNewFilterAppliedAffordance = true;
    }

    async addAdditionalFilters(filters: AdditionalFilter[], pjaxReload = true) {
        await GlobalFilterService.addAdditionalFilters(filters, pjaxReload);
        if (filters.length > 0) {
            GlobalFilterService.shouldShowNewFilterAppliedAffordance = true;
        }
    }

    async addStatus(status: string) {
        var statuses = window.globalFilterData.appliedStatuses;
        statuses.push(status);
        await GlobalFilterService.applyStatuses(statuses);
    }
}