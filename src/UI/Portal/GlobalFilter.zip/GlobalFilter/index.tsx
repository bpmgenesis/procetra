import * as React from "react";
import * as ReactDOM from "react-dom";
import { GlobalFilter, GlobalFilterProps } from "./GlobalFilter";
import { GlobalFilterService } from "./GlobalFilterService";
import { RecentlyViewedClass, RecentlyViewed } from "./RecentlyViewed";
import { TagStrip } from "./TagStrip";

// Merge our window properties on top of the existing DOM Window type definition
declare global {
    interface Window {
        pjaxLoad: (url: string) => void,
        pjaxReload: () => void,
        pjaxReplace: (url: string) => void,
        globalFilterData: GlobalFilterProps,
        $: JQueryStatic,
        renderGlobalFilter: (globalFilterdata: GlobalFilterProps) => void,
        unmountGlobalFilter: () => void,
        moment: any,
        globalFilter: typeof GlobalFilterService,
        RecentlyViewed: RecentlyViewedClass,
        gtag: (command: "event", eventName: string, eventParams: {event_category: string, event_label: string, value?: number}) => void,
        getSessionStorageItem: (key: string) => string,
        setSessionStorageItem: (key: string, value: string) => void,
        TagStrip: TagStrip,
        trackUi: {
            copyToClipboard: (stringToCopy: string) => void
        }
    }
}

window.renderGlobalFilter = (globalFilterData: GlobalFilterProps) => {
    ReactDOM.render(
        <GlobalFilter {...globalFilterData} />,
        document.getElementById("global-filter-root")
    );
}

window.unmountGlobalFilter = () => {
    var globalFilterElement = document.getElementById("global-filter-root");
    if (globalFilterElement) {
        ReactDOM.unmountComponentAtNode(globalFilterElement);
    }
}

window.globalFilter = GlobalFilterService;
window.RecentlyViewed = RecentlyViewed;
window.TagStrip = new TagStrip();
