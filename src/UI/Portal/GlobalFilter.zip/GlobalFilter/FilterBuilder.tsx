import * as React from "react";
import { GlobalFilterProps } from "./GlobalFilter";
import { ErrorFilterBuilder } from "./FilterBuilderTabs/ErrorFilterBuilder";
import { FilterStore, AdditionalFilter, MAX_FILTERS } from "./FilterStore";
import { GlobalFilterService } from "./GlobalFilterService";
import { BrowserFilterBuilder } from "./FilterBuilderTabs/BrowserFilterBuilder";
import { UserFilterBuilder } from "./FilterBuilderTabs/UserFilterBuilder";
import { DomainFilterBuilder } from "./FilterBuilderTabs/DomainFilterBuilder";
import { VersionFilterBuilder } from "./FilterBuilderTabs/VersionFilterBuilder";
import { MetadataFilterBuilder } from "./FilterBuilderTabs/MetadataFilterBuilder";
import { stripDelimiter } from "./FilterBuilderTabs/stripDelimiter";
import { FilterKindIcon } from "./FilterKindIcon";
import { EntryFilterBuilder } from "./FilterBuilderTabs/EntryFilterBuilder";
import { IpAddressFilterBuilder } from "./FilterBuilderTabs/IpAddressFilterBuilder";
import { StackTraceFilterBuilder } from "./FilterBuilderTabs/StackTraceFilterBuilder";

const LAST_TAB_KEY = "filterBuilder_lastTab";

export interface FilterBuilderState {
    builderOpen: boolean;
    selectedTab: SelectedFilterBuilderTab;
    additionalFilters: AdditionalFilter[];
    showAllAppliedFilters: boolean
    isApplyingFilters: boolean
}

export enum SelectedFilterBuilderTab {
    Unknown,
    Error,
    Browser,
    Users,
    Version,
    Domain,
    Metadata,
    Entry,
    StackTrace,
    IpAddress
}

interface FilterBuilderProps extends GlobalFilterProps {

}

export class FilterBuilder extends React.PureComponent<FilterBuilderProps, FilterBuilderState> {

    constructor(props: FilterBuilderProps) {
        super(props);
        var lastTab = window.getSessionStorageItem(LAST_TAB_KEY);
        this.state = {
            builderOpen: false,
            selectedTab: SelectedFilterBuilderTab[lastTab] || SelectedFilterBuilderTab.Error,
            additionalFilters: props.additionalFilters,
            showAllAppliedFilters: false,
            isApplyingFilters: false
        }

        this.builderOpenRef = React.createRef();


        FilterStore.initialize(
            () => this.state.additionalFilters,
            (filters) => this.setState({ additionalFilters: filters }),
            this.props.additionalFilters
        );
    }

    public builderOpenRef: React.RefObject<HTMLDivElement>

    componentWillMount() {
        document.addEventListener("mousedown", this.handleFilterBuilderOutsideClick, false);
        document.addEventListener("keydown", this.handleFilterBuilderKeyDown, false);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleFilterBuilderOutsideClick, false);
        document.removeEventListener("keydown", this.handleFilterBuilderKeyDown, false);
    }

    componentDidMount() {
        // We show it on render, so once the component is mounted we can "cancel" it.
        GlobalFilterService.shouldShowNewFilterAppliedAffordance = false;
    }

    handleFilterBuilderOutsideClick = (evt) => {
        if (!document.body.contains(evt.target) || this.builderOpenRef.current.contains(evt.target)) {
            return;
        }
        else {
            this.setState({
                builderOpen: false,
                showAllAppliedFilters: false
            });
        }
    }

    handleFilterBuilderKeyDown = (evt: KeyboardEvent) => {
        if (evt.keyCode === 27) { // esc
            if (this.state.builderOpen) {
                this.openOrCloseBar();
            }
        }
    }

    render() {
        var allFilters = this.renderAppliedFilters();
        var appliedFilters = allFilters;
        var showClearAll = appliedFilters.length > 0;
        var maxVisibleFilters = this.calculateMaxVisibleFilters();
        var hiddenFilters = [];
        if (appliedFilters.length > maxVisibleFilters) {
            appliedFilters = allFilters.slice(0, maxVisibleFilters);
            hiddenFilters = allFilters.slice(maxVisibleFilters);
        }

        // Positioning the bar
        var windowWidth = window.innerWidth;
        var left = "0";
        var width = "100%";
        var minGutterWidth = 85;
        var maxDrawerWidth = 1250;

        if (this.builderOpenRef.current) {
            var builderBarPosition = this.builderOpenRef.current.getBoundingClientRect();
            // If the bar itself is narrower than we want the drawer to be, then we need to figure out how to position the expanded drawer
            if (builderBarPosition.width < maxDrawerWidth) {
                var sideOffset = (maxDrawerWidth - builderBarPosition.width) / 2;
                // We can, let's center the bar directly underneath the builder bar.
                if ((builderBarPosition.left - sideOffset) > 75 && ((windowWidth - builderBarPosition.right) - sideOffset) > 75) {
                    left = `${(-1 * sideOffset)}px`;
                    width = `${maxDrawerWidth}px`;
                }
                else {
                    // Their screen is too small to center the drawer directly under the bar, so we'll center with respect to the viewport.
                    left = `${(-1 * builderBarPosition.left) + minGutterWidth}px`;
                    width = `${windowWidth - (minGutterWidth * 2)}px`;
                }
            }
            // Otherwise the drawer can just be the full width of the bar, since the bar is bigger than we want the drawer to be (but it would look silly to shrink it)
        }
        return (
            <div className="filter-builder-container align-center" ref={this.builderOpenRef} >
                <div className={`filter-builder flex-column ${GlobalFilterService.shouldShowNewFilterAppliedAffordance ? 'filter-highlight-border' : ''}`}>
                    <div className={`filter-builder-header`} onClick={(evt) => this.openOrCloseBar()}>
                        <i className={`fa fa-filter ${GlobalFilterService.shouldShowNewFilterAppliedAffordance ? 'filter-highlight-color' : ''}`}></i>
                        <div className={`current-filters flex`}>
                            {appliedFilters.length > 0 && appliedFilters}
                            {allFilters.length === 0 &&
                                <span className="add-custom-filters">Add Custom Filters</span>
                            }
                        </div>
                        {hiddenFilters.length > 0 && !this.state.showAllAppliedFilters &&
                            <button className="show-more-filters" onClick={e => this.toggleAllAppliedFilters(e, true)}>
                                And {hiddenFilters.length} more
                            </button>
                        }
                        {this.state.showAllAppliedFilters &&
                            <button className="show-more-filters" onClick={e => this.toggleAllAppliedFilters(e, false)}>
                                Show Less
                            </button>
                        }
                        {showClearAll &&
                            <span className="clear-all-filters">
                                <button onClick={e => this.removeFilter(e)}>Clear All</button>
                            </span>
                        }
                    </div>
                    <div className={`filter-builder-body flex-column ${this.state.showAllAppliedFilters ? "showing-all" : ""}`}
                        style={{ display: (this.state.builderOpen || this.state.showAllAppliedFilters) ? "flex" : "none", left: left, width: width }}>

                        {this.state.showAllAppliedFilters &&
                            <div className={`current-filters flex showing-all`}>
                                {hiddenFilters}
                            </div>
                        }

                        <div className="tabs flex" style={{ display: this.state.builderOpen ? "flex" : "none" }}>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Error ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Error) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Error)}>
                                <i className="fa fa-exclamation-triangle"></i>&nbsp;Error<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Error).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Error).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Entry ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Entry) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Entry)}>
                                <i className="fa fa-arrow-circle-right"></i>&nbsp;Entry<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Entry).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Entry).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Domain ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Domain) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Domain)}>
                                <i className="fa fa-fw icon-urls"></i>&nbsp;Url<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Domain).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Domain).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Users ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Users) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Users)}>
                                <i className="icon-users"></i>&nbsp;Users<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Users).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Users).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Version ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Version) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Version)}>
                                <i className="fa fa-code-fork"></i>&nbsp;Version<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Version).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Version).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Browser ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Browser) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Browser)}>
                                <i className="icon-browsers"></i>&nbsp;Browser<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Browser).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Browser).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.Metadata ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.Metadata) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.Metadata)}>
                                <i className="icon-metadata"></i>&nbsp;Metadata<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Metadata).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.Metadata).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.StackTrace ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.StackTrace) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.StackTrace)}>
                                <i className="icon-metadata"></i>&nbsp;Stack Trace<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.StackTrace).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.StackTrace).length}
                                    </span>
                                }
                            </div>
                            <div className={`
                                tab
                                ${this.state.selectedTab == SelectedFilterBuilderTab.IpAddress ? 'selected' : ''}
                                ${FilterStore.hasUnsavedChanges(SelectedFilterBuilderTab.IpAddress) ? 'unsaved' : ''}
                            `}
                                onClick={e => this.selectTab(e, SelectedFilterBuilderTab.IpAddress)}>
                                <i className="icon-metadata"></i>&nbsp;IP Address<span className="unsaved">&nbsp;*</span>
                                {FilterStore.getProposedFilters(SelectedFilterBuilderTab.IpAddress).length > 0 &&
                                    <span className="current-filter-count">
                                        {FilterStore.getProposedFilters(SelectedFilterBuilderTab.IpAddress).length}
                                    </span>
                                }
                            </div>
                        </div>
                        <div className="tab-details" style={{ display: this.state.builderOpen ? "flex" : "none" }}>
                            {this.renderTabDetails(this.state.selectedTab)}
                        </div>
                        <div className="apply-cancel" style={{ display: this.state.builderOpen ? "flex" : "none" }}>
                            {this.state.additionalFilters.length >= MAX_FILTERS && <span className="too-many-filters">You've reached the maximum number of filters.</span>}
                            <button className="apply" onClick={e => this.applyFilter(e)}>
                                {this.state.isApplyingFilters &&
                                    <span>Applying...</span>
                                }
                                {!this.state.isApplyingFilters &&
                                    <span>Apply</span>
                                }
                            </button>
                            <button className="cancel" onClick={e => this.cancelFilter(e)}>Cancel</button>
                        </div>


                    </div>
                </div>
            </div>
        )
    }

    calculateMaxVisibleFilters() {
        var windowWidth = window.innerWidth;
        var otherChromeWidth = this.props.applications ? 1100 : 850;
        var availableWidth = windowWidth - otherChromeWidth;
        var numToShow = 0;
        var spaceConsumed = 0;
        for (var i = 0; (i < this.props.additionalFilters.length) && (spaceConsumed < (availableWidth - 50)); i++) {
            var filter = this.props.additionalFilters[i];
            if (filter.displayValue.length > 30) {
                spaceConsumed += 400;
            }
            else if (filter.displayValue.length > 20) {
                spaceConsumed += 350;
            }
            else if (filter.displayValue.length > 10) {
                spaceConsumed += 300;
            }
            else {
                spaceConsumed += 250;
            }
            numToShow++;
        }

        return Math.max(1, numToShow);
    }

    renderAppliedFilters() {
        var additionalFilters = this.props.additionalFilters.map(filter => {
            return (
                <div className="filter-item" key={filter.displayKey + filter.displayValue} onClick={e => this.filterItemClicked(e, filter)}>
                    <span className="filter-key">{filter.displayKey}</span>
                    <FilterKindIcon filter={filter} />
                    <span title={stripDelimiter(filter.displayValue)} className="filter-value">
                        <span className="filter-text">{stripDelimiter(filter.displayValue)}</span>
                        <span className="remove-filter" onClick={e => this.removeFilter(e, filter)}><i className="fa fa-times-circle"></i></span>
                    </span>
                </div>
            )
        });

        return additionalFilters;
    }

    renderTabDetails(selectedTab: SelectedFilterBuilderTab) {
        return (
            <div>
                <ErrorFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Error} additionalFilters={this.state.additionalFilters} />

                <BrowserFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Browser} additionalFilters={this.state.additionalFilters} />

                <UserFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Users} additionalFilters={this.state.additionalFilters} />

                <VersionFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Version} additionalFilters={this.state.additionalFilters} />

                <DomainFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Domain} additionalFilters={this.state.additionalFilters} />

                <MetadataFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Metadata} additionalFilters={this.state.additionalFilters} />

                <EntryFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.Entry} additionalFilters={this.state.additionalFilters} />

                <StackTraceFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.StackTrace} additionalFilters={this.state.additionalFilters} />

                <IpAddressFilterBuilder isVisible={this.state.builderOpen && selectedTab === SelectedFilterBuilderTab.IpAddress} additionalFilters={this.state.additionalFilters} />
            </div>
        )
    }

    openOrCloseBar() {
        var builderOpen = !this.state.builderOpen
        if (!builderOpen) {
            this.setState({
                showAllAppliedFilters: false
            });
        }
        this.setState({
            builderOpen: builderOpen
        });
    }

    selectTab(evt, selectedTab: SelectedFilterBuilderTab) {
        evt.preventDefault();
        evt.stopPropagation();
        this.setState({
            selectedTab: selectedTab
        });
        window.setSessionStorageItem(LAST_TAB_KEY, SelectedFilterBuilderTab[selectedTab])
    }

    cancelFilter(evt) {
        this.setState({
            builderOpen: false,
            additionalFilters: this.props.additionalFilters
        });
    }

    toggleAllAppliedFilters(evt, showAll: boolean) {
        evt.preventDefault();
        evt.stopPropagation();
        this.setState({
            showAllAppliedFilters: showAll
        });
    }

    filterItemClicked(evt, filter: AdditionalFilter) {
        evt.preventDefault();
        evt.stopPropagation();
        var selectedTab = SelectedFilterBuilderTab.Error;
        switch (filter.type) {
            case "browser":
            case "browserSearch":
                selectedTab = SelectedFilterBuilderTab.Browser;
                break;
            case "user":
            case "userSearch":
                selectedTab = SelectedFilterBuilderTab.Users;
                break;
            case "version":
            case "versionSearch":
                selectedTab = SelectedFilterBuilderTab.Version;
                break;
            case "domain":
                selectedTab = SelectedFilterBuilderTab.Domain;
                break;
            case "metadata":
                selectedTab = SelectedFilterBuilderTab.Metadata;
                break;
            case "stacktraceSearch":
                selectedTab = SelectedFilterBuilderTab.StackTrace;
                break;
            case "ip":
            case "ipSearch":
                selectedTab = SelectedFilterBuilderTab.IpAddress;
                break;
            default:
                selectedTab = SelectedFilterBuilderTab.Error;
                break;
        }
        this.setState({
            selectedTab: selectedTab,
            builderOpen: true
        });
    }

    async applyFilter(evt) {
        this.setState({
            isApplyingFilters: true
        });
        await GlobalFilterService.applyFilters(FilterStore.getState());
        if (FilterStore.getState().length > 0) {
            GlobalFilterService.shouldShowNewFilterAppliedAffordance = true;
        }
    }

    async removeFilter(evt: React.MouseEvent<HTMLSpanElement>, filter = null) {
        evt.stopPropagation();
        await GlobalFilterService.removeAdditionalFilter(filter);
    }
}