import { AdditionalFilter } from "./FilterStore";

export type AutocompleteResult = {
    Query: string,
    ExactValues: { Key: string, Value: number, FilterTypeOverride: string }[],
    SearchResultCount: number
}

export class GlobalFilterService {
    static async clearAll() {
        await $.ajax({
            url: "/filter/clear",
            method: "POST",
            contentType: "application/json",
            dataType: "json"
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'clear-all' });
        window.pjaxReload();
    }

    static async clearTimeRange() {
        await $.post(`/filter/cleartime`);
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'date-clear' });
        window.pjaxReload();
    }

    static async applyStatuses(statuses: string[]) {
        var payload = {
            statuses: statuses
        }
        await $.ajax({
            url: "/filter/status",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify(payload)
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'status-filter' });
        window.pjaxReload();
    }

    static async switchApplication(id: string) {
        await $.post(`/Account/Applications/switch/${id}`, {});
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'application-filter' });
        window.pjaxReload();
    }

    static async applyCustomDateRange(minDate: string, maxDate: string) {
        await $.ajax({
            url: "/filter/fixedRange",
            method: "POST",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
                minDate: minDate,
                maxDate: maxDate
            })
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'date-filter-custom' });
        window.pjaxReload();
    }

    static async applyRelativeDateRange(minutesFromNow: number) {
        await $.post(`/filter/fromnow?minutesFromNow=${minutesFromNow}`);
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'date-filter-relative' });
        window.pjaxReload();
    }

    static async addAdditionalFilter(key: string, value: string, isNegated = false, pjaxReload = true) {
        await $.ajax({
            url: "/filter/additional",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                type: key,
                value: value,
                isNegated: isNegated
            })
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': `additional-filter-from-page:${key}` });
        if (pjaxReload) {
            window.pjaxReload();
        }
    }

    static async removeAdditionalFilter(filter) {
        var payload = {
            filter: filter
        };

        await $.ajax({
            url: "/filter/clearAdditional",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify(payload)
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'additional-clear' });
        window.pjaxReload();
    }

    static async addAdditionalFilters(filters: AdditionalFilter[], pjaxReload = true) {
        await $.ajax({
            url: "/filter/additional-multiple",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({ filters: filters })
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': `additional-filters`, 'value': filters.length });
        if (pjaxReload) {
            window.pjaxReload();
        }
    }

    static async applyFilters(filters: AdditionalFilter[]) {
        await $.ajax({
            url: "/filter/apply",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({ filters: filters })
        });
        GlobalFilterService.clearPageQueryParam();
        window.gtag('event', 'filter_bar', { 'event_category': 'engagement', 'event_label': 'apply-filters', 'value': filters.length });
        window.pjaxReload();
    }

    static async getMessageFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]): Promise<AutocompleteResult> {
        return await $.ajax({
            url: "/filter/messageAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getMessageFilterTopMessages(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topMessages",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topMessages;
    }

    static async getBrowserFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]) {
        return await $.ajax({
            url: "/filter/browserAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getBrowserFilterTopBrowsers(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topBrowsers",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topBrowsers;
    }

    static async getUserFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]) {
        return await $.ajax({
            url: "/filter/userAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getUserFilterTopUsers(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topUsers",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topUsers;
    }

    static async getVersionFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]) {
        return await $.ajax({
            url: "/filter/versionAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getVersionFilterTopVersions(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topVersions",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topVersions;
    }

    static async getDomains(proposedFilters: AdditionalFilter[]): Promise<{ Key: string, Value: number }[]> {
        var result = await $.ajax({
            url: "/filter/domains",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.domains;
    }

    static async getDomainAutocomplete(text: string, proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/domainAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });

        result.ExactValues.forEach(x => x.FilterTypeOverride = "domain");

        var urlResult = await GlobalFilterService.getUrlFilterAutocomplete(text, proposedFilters);

        result.Query = urlResult.Query;
        result.SearchResultCount = urlResult.SearchResultCount;
        result.ExactValues = result.ExactValues.concat(urlResult.ExactValues);

        return result;
    }

    static async getUrlFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/urlAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });

        result.ExactValues.forEach(x => x.FilterTypeOverride = "url");

        return result;
    }

    static async getUrlFilterTopUrls(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topUrls",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topUrls;
    }

    static async getMetadataFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]) {
        return await $.ajax({
            url: "/filter/metadataAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getMetadataFilterTopMetadata(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topMetadata",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topMetadata;
    }

    static async getTopEntriesAndPlatforms(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topEntries",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result;
    }

    static async getStackTraceFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]): Promise<AutocompleteResult> {
        return await $.ajax({
            url: "/filter/stackTraceAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getIpAddressFilterAutocomplete(text: string, proposedFilters: AdditionalFilter[]): Promise<AutocompleteResult> {
        return await $.ajax({
            url: "/filter/ipAddressAutocomplete",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                text: text,
                proposedFilters: proposedFilters
            })
        });
    }

    static async getTopIpAddresses(proposedFilters: AdditionalFilter[]) {
        var result = await $.ajax({
            url: "/filter/topIpAddresses",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                proposedFilters: proposedFilters
            })
        });

        return result.topIpAddresses;
    }

    // Removes the page query param from the url, if present, so the user returns to page 1 in the list after applying filters.
    static clearPageQueryParam() {
        var currentUrl = new window.Url(window.location.toString());
        delete currentUrl.query["page"];
        window.pjaxReplace(currentUrl.toString());
    }

    static async getSavedFilters() {
        var result = await $.ajax({
            url: "/filter/get-saved-filters",
            method: "GET"
        });

        return result.savedFilterNames;
    }

    static async saveCurrentFilter(filterName: string) {
        var result = await $.ajax({
            url: "/filter/save-current-filter",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                filterName: filterName
            })
        });

        return result.success;
    }

    static async applySavedFilter(filterName: string) {
        var result = await $.ajax({
            url: "/filter/load-saved-filter",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                filterName: filterName
            })
        });

        return result.success;
    }

    static async deleteSavedFilter(filterName: string) {
        var result = await $.ajax({
            url: "/filter/delete-saved-filter",
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                filterName: filterName
            })
        });

        return result.success;
    }

    /// This guy determines whether we "flash" the filter bar as a UI affordance, telling the user something new was added.
    static shouldShowNewFilterAppliedAffordance = false;
}
