import { SelectedFilterBuilderTab } from "./FilterBuilder";

export type AdditionalFilter = {
    type: string;
    displayKey: string,
    displayValue: string,
    rawValue: string,
    isNegated?: boolean
}

export const MAX_FILTERS = 20;

var filterFuncs: {
    [selectedTab: string]: (filter: AdditionalFilter) => boolean
} = {}

class _FilterStore {

    getState: () => AdditionalFilter[];
    setState: (additionalFilters: AdditionalFilter[]) => void;
    originallyAppliedFilters: AdditionalFilter[] = [];

    initialize(getState, setState, originallyAppliedFilters) {
        this.getState = getState;
        this.setState = setState;
        this.originallyAppliedFilters = originallyAppliedFilters;

        // These have to go inside initialize(), otehrwise SelectedFilterBuilderTab is not yet "defined" due to cyclic referencing.
        // If we hate that these go here, we could re-jigger the reference order but that felt like more trouble than it was worth.
        filterFuncs[SelectedFilterBuilderTab.Error] = x => x.type === "message" || x.type === "messageSearch";
        filterFuncs[SelectedFilterBuilderTab.Browser] = x => x.type === "browser" || x.type === "browserSearch";
        filterFuncs[SelectedFilterBuilderTab.Users] = x => x.type === "user" || x.type === "userSearch";
        filterFuncs[SelectedFilterBuilderTab.Domain] = x => x.type === "domain" || x.type === "url" || x.type === "urlSearch";
        filterFuncs[SelectedFilterBuilderTab.Version] = x => x.type === "version" || x.type === "versionSearch";
        filterFuncs[SelectedFilterBuilderTab.Metadata] = x => x.type === "metadata";
        filterFuncs[SelectedFilterBuilderTab.Entry] = x => x.type === "entry" || x.type === "platform";
        filterFuncs[SelectedFilterBuilderTab.StackTrace] = x => x.type === "stacktraceSearch";
        filterFuncs[SelectedFilterBuilderTab.IpAddress] = x => x.type === "ip" || x.type === "ipSearch";
    }

    addFilter(filter: AdditionalFilter) {
        if (this.getState().length >= MAX_FILTERS) {
            return;
        }
        var existingFilter = this.getState().find(x => x.type === filter.type && x.rawValue === filter.rawValue);
        if (!existingFilter) {
            var existingFilters = this.getState();
            var newFilters = [].concat(existingFilters, [filter])
            this.setState(newFilters);
        }
    }

    removeFilter(filter: AdditionalFilter) {
        var remainingFilters = [].concat(this.getState());
        var indexOfFilter = remainingFilters.findIndex(x => x.type === filter.type && x.rawValue === filter.rawValue);
        if (indexOfFilter >= 0) {
            remainingFilters.splice(indexOfFilter, 1);
            this.setState(remainingFilters);
        }
    }

    hasUnsavedChanges(tab: SelectedFilterBuilderTab) {
        var appliedFilters = this.originallyAppliedFilters.filter(filterFuncs[tab]);
        var proposedFilters = this.getProposedFilters(tab);

        if (appliedFilters.length != proposedFilters.length) {
            return true;
        }
        for (var i = 0; i < appliedFilters.length; i++) {
            var appliedFilter = appliedFilters[i];
            var doesProposedFiltersContainAppliedFilter = !!proposedFilters.find(x => x.type === appliedFilter.type && x.rawValue === appliedFilter.rawValue);
            if (!doesProposedFiltersContainAppliedFilter) {
                return true;
            }
        }

        return false;
    }

    getProposedFilters(tab: SelectedFilterBuilderTab): AdditionalFilter[] {
        return (this.getState() || []).filter(filterFuncs[tab]);
    }

}

export var FilterStore = new _FilterStore();