const MAX_RECENT_LENGTH = 3;
const RECENT_KEY = (kind: RecentlyViewedKind) => `recentlyViewed_${kind}`;
const PRIVATE_BACKING_STORE = (kind: RecentlyViewedKind) => `_${kind}`; // looks like _recentMessages

type RecentlyViewedKind = "recentMessages" | "recentBrowsers" | "recentUsers" | "recentVersions";

export class RecentlyViewedClass {

    private _recentMessages: string[] = null;
    private _recentBrowsers: string[] = null;
    private _recentUsers: string[] = null;
    private _recentVersions: string[] = null;

    public addMessage(message: string) {
        this.addRecentlyViewedItem("recentMessages", message);
    }

    public addBrowser(browser: string) {
        this.addRecentlyViewedItem("recentBrowsers", browser);
    }

    public addUser(user: string) {
        this.addRecentlyViewedItem("recentUsers", user);
    }

    public addVersion(version: string) {
        this.addRecentlyViewedItem("recentVersions", version);
    }

    public get recentMessages(): string[] {
        return this.getRecentItems("recentMessages");
    }

    public get recentBrowsers(): string[] {
        return this.getRecentItems("recentBrowsers");
    }

    public get recentUsers(): string[] {
        return this.getRecentItems("recentUsers");
    }

    public get recentVersions(): string[] {
        return this.getRecentItems("recentVersions");
    }

    private getLocalStorageItem(key: string): string[] {
        try {
            return JSON.parse(localStorage.getItem(key)) || [] as string[];
        }
        catch (e) {
            return [];
        }
    }

    private setLocalStorageItem(key: string, values: string[]) {
        try {
            localStorage.setItem(key, JSON.stringify(values));
        }
        catch (e) {
        }
    }

    private addRecentlyViewedItem(kind: RecentlyViewedKind, item: string) {
        if (!item) {
            return;
        }
        var items = this[kind];
        var indexOfExistingItem = items.indexOf(item);
        if (indexOfExistingItem >= 0) {
            items.splice(indexOfExistingItem, 1);
            items.unshift(item);
        }
        else {
            items.unshift(item);
            if (items.length > MAX_RECENT_LENGTH) {
                items.pop();
            }
        }

        this[PRIVATE_BACKING_STORE(kind)] = [].concat(items);
        this.setLocalStorageItem(RECENT_KEY(kind), items);
    }

    private getRecentItems(kind: RecentlyViewedKind): string[] {
        if (this[PRIVATE_BACKING_STORE(kind)] === null) {
            this[PRIVATE_BACKING_STORE(kind)] = this.getLocalStorageItem(RECENT_KEY(kind));
        }

        return this[PRIVATE_BACKING_STORE(kind)];
    }

}

export var RecentlyViewed = new RecentlyViewedClass();