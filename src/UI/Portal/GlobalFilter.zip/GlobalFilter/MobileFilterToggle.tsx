import { Teact, DomHandler, Control, React } from '@tuval/forms';
import { GlobalFilterProps } from "./GlobalFilter";
import { GlobalFilterService } from "./GlobalFilterService";

export class MobileFilterToggle extends React.PureComponent<GlobalFilterProps, { isSelected: boolean }>{
    constructor(props) {
        super(props);
        this.state = {
            isSelected: false
        }
    }

    render() {
        return (
            <div className={`filter-dropdown mobile-filter-toggle ${this.state.isSelected ? "selected" : ""}`}>
                <div className="filter-dropdown-title" style={{ width: "100%" }} onClick={e => this.toggleSelected()}>
                    <div className="flex">
                        <i className="fa fa-filter"></i>
                    </div>
                    {this.props.additionalFilters.length > 0 &&
                        <div className=" flex">
                            <div className="mobile-current-filters">
                                {this.props.additionalFilters.length} filter{this.props.additionalFilters.length !== 1 ? "s" : ""} applied
                            </div>
                            <button className="mobile-clear-filters" onClick={e => this.removeAllFilters(e)}>
                                Clear
                            </button>
                        </div>
                    }
                    <div className="flex align-center">
                        <i className="fa fa-caret-down" style={{ marginLeft: "auto" }}></i>
                    </div>
                </div>
            </div>
        )
    }


    toggleSelected() {
        this.setState({
            isSelected: !this.state.isSelected
        });
    }

    async removeAllFilters(evt: any) {
        evt.stopPropagation();
        await GlobalFilterService.removeAdditionalFilter(null);
    }
}