import * as React from "react";
import { GlobalFilterProps } from "./GlobalFilter";
import { Range } from "rc-slider";
import { Moment } from "moment";
import { GlobalFilterService } from "./GlobalFilterService";

declare interface DateRangePickerState {
    start: Moment,
    end: Moment,
    startString: string,
    endString: string,
    customOpen: boolean,
    minDate?: string,
    maxDate?: string,
    minutesFromNow?: number
}

const _1h = 60;
const _8h = _1h * 8;
const _24h = _1h * 24;
const _3d = _24h * 3;
const _7d = _24h * 7;

export class DateRangePicker extends React.PureComponent<GlobalFilterProps, DateRangePickerState> {

    public marks: {}
    public minimumDate?: Moment
    public maximumDate?: Moment
    public pickerRef: React.RefObject<HTMLDivElement>
    public toggleRef: React.RefObject<HTMLAnchorElement>

    constructor(props: GlobalFilterProps) {
        super(props);
        var start: Moment = null, end: Moment = null;
        var startString:string = "", endString:string = "";
        if (props.minDate) {
            start = window.moment(props.minDate);
            startString = start.format();
        }
        if (props.maxDate) {
            end = window.moment(props.maxDate);
            endString = end.format();
        }
        this.state = {
            start: start,
            end: end,
            startString: startString,
            endString: endString,
            customOpen: false,
            maxDate: props.maxDate,
            minDate: props.minDate,
            minutesFromNow: props.minutesFromNow
        }
        this.pickerRef = React.createRef();
        this.toggleRef = React.createRef();
        this.calculateDateRangeSliderValues();
    }

    componentWillMount() {
        document.addEventListener("mousedown", this.handleOutsideClick, false);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleOutsideClick, false);
    }

    calculateDateRangeSliderValues() {
        var retentionDays = window.globalFilterData.customer.retentionDays;
        this.maximumDate = window.moment() as Moment;
        this.minimumDate = window.moment().subtract(this.props.customer.retentionDays, "days").startOf("day") as Moment;
        var cursor = window.moment(this.minimumDate) as Moment;
        var counter = 1;
        var marks = {};
        while (cursor < this.maximumDate) {
            if (counter % 2 === 0 && retentionDays > 15) {
                marks[cursor.unix()] = "";
            }
            else {
                marks[cursor.unix()] = cursor.format("MMM Do")
            }
            cursor.add(1, "day");
            counter++;
        }
        marks[this.maximumDate.unix()] = "";
        this.marks = marks;
    }

    render() {
        return (
            <div className="date-range-picker relative">
                <i className="fa fa-clock-o"></i>
                <a className={`${this.isRelativeRangeSelected(_1h) ? "selected" :""}`} href="javascript:void(0)" onClick={e => this.setRelativeRange(_1h)}>1H</a>
                <a className={`${this.isRelativeRangeSelected(_8h) ? "selected" : ""}`} href="javascript:void(0)" onClick={e => this.setRelativeRange(_8h)}>8H</a>
                <a className={`${this.isRelativeRangeSelected(_24h) ? "selected" : ""}`} href="javascript:void(0)" onClick={e => this.setRelativeRange(_24h)}>24H</a>
                <a className={`${this.isRelativeRangeSelected(_3d) ? "selected" : ""}`}  href="javascript:void(0)" onClick={e => this.setRelativeRange(_3d)}>3D</a>
                <a className={`${this.isRelativeRangeSelected(_7d) ? "selected" : ""}`} href="javascript:void(0)" onClick={e => this.setRelativeRange(_7d)}>7D</a>
                <a className={`${this.isRelativeRangeSelected(null) ? "selected" : ""}`} href="javascript:void(0)" onClick={e => this.clearRange()}>All</a>
                <a href="javascript:void(0)"
                    onClick={e => this.toggleCustomPicker()} ref={this.toggleRef}
                    className={`custom-date-button ${this.state.customOpen ? "open" : ""} ${this.isAbsoluteRangeSelected() ? "selected" : ""}`}>
                    Custom
                </a>
                {this.state.customOpen &&
                <div className="custom-date" ref={this.pickerRef}>
                    <div className="flex" style={{
                        justifyContent: "space-between",
                        marginBottom: "15px"
                    }}>
                        <div className="flex-column">
                            <label>START DATE</label>
                            <input type="text" value={this.state.startString} onChange={e => this.onStartChange(e.target.value)} style={{ width: "250px" }} placeholder="Beginning of Time" />
                        </div>
                        <div className="flex-column">
                            <label>END DATE</label>
                            <input type="text" value={this.state.endString} onChange={e => this.onEndChange(e.target.value)} style={{ width: "250px" }} placeholder="Now" />
                        </div>
                    </div>
                    <Range marks={this.marks}
                        value={[
                            this.state.start ? this.state.start.unix() : this.minimumDate.unix(),
                            this.state.end ? this.state.end.unix() : this.maximumDate.unix()
                        ]}
                        min={this.minimumDate.unix()}
                        max={this.maximumDate.unix()}
                        step={60}
                        defaultValue={[this.minimumDate.unix(), this.maximumDate.unix()]}
                        onChange={range => this.onRangeChange(range)}>
                    </Range>
                    <button onClick={e => this.applyCustomDateRange()}>Apply</button>
                </div>
                }
            </div>
            )
    }

    async setRelativeRange(minutesFromNow: number) {
        this.setState({
            minutesFromNow: minutesFromNow,
            minDate: null,
            maxDate: null
        });
        await GlobalFilterService.applyRelativeDateRange(minutesFromNow);
    }

    async clearRange() {
        this.setState({
            minutesFromNow: null,
            minDate: null,
            maxDate: null
        });
        await GlobalFilterService.clearTimeRange();
    }

    isRelativeRangeSelected(minutesFromNow: number): boolean {
        if (this.isAbsoluteRangeSelected()) {
            return false;
        }
        return this.state.minutesFromNow === minutesFromNow;
    }

    isAbsoluteRangeSelected(): boolean {
        return !!this.state.minDate || !!this.state.maxDate;
    }

    toggleCustomPicker() {
        this.setState({
            customOpen: !this.state.customOpen
        });
    }

    onStartChange(startValue: string) {
        var newStart = window.moment(startValue) as Moment;
        var state = {
            startString: startValue
        } as any;
        if (newStart.isValid()) {
            state.start = newStart;
        }
        else if (startValue === "") {
            state.start = null;
        }
        this.setState(state);
    }

    onEndChange(endValue: string) {
        var newEnd = window.moment(endValue) as Moment;
        var state = {
            endString: endValue
        } as any;
        if (newEnd.isValid()) {
            state.end = newEnd;
        }
        else if (endValue === "") {
            state.end = null;
        }
        this.setState(state);
    }

    onRangeChange([startSeconds, endSeconds]: number[]) {
        var start = window.moment.unix(startSeconds) as Moment;
        var end = window.moment.unix(endSeconds) as Moment;
        if (startSeconds != this.minimumDate.unix()) {
            this.setState({
                start: start,
                startString: start.format(),
            });
        }
        if (endSeconds != this.maximumDate.unix()) {
            this.setState({
                end: end,
                endString: end.format()
            });
        }
    }

    async applyCustomDateRange() {
        var minDate = this.state.start && this.state.start.isValid() ? this.state.start.format() : null;
        var maxDate = this.state.end && this.state.end.isValid() ? this.state.end.format() : null
        this.setState({
            minutesFromNow: null,
            minDate: minDate,
            maxDate: maxDate
        });
        await GlobalFilterService.applyCustomDateRange(minDate, maxDate);
    }

    handleOutsideClick = (evt) => {
        if (!this.state.customOpen) {
            return;
        }

        if (!document.body.contains(evt.target) ||
            this.pickerRef.current.contains(evt.target) ||
            this.toggleRef.current.contains(evt.target)) {
            return;
        }
        else {
            this.setState({
                customOpen: false
            });
        }
    }
}