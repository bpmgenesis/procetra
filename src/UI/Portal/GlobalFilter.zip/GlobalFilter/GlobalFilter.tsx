import * as React from "react";
import { ApplicationDropdown } from "./ApplicationDropdown";
import { StatusDropdown } from "./StatusDropdown";
import { DomainDropdown } from "./DomainDropdown";
import { FilterBuilder } from "./FilterBuilder";
import { DateRangePicker } from "./DateRangePicker";
import { MobileFilterToggle } from "./MobileFilterToggle";
import { AdditionalFilter } from "./FilterStore";
import { SavedFilters } from "./SavedFilters";

export interface GlobalFilterProps {
    currentApplicationKey: string,
    application?: {
        name: string,
        slug: string,
        id: string
    },
    applications: {
        name: string,
        id: string,
        slug: string
    }[],
    allStatuses: string[],
    appliedStatuses: string[],
    displayStatus: string,
    availableDomains: string[]
    currentDomain: string,
    customer: {
        maxApplications: number;
        retentionDays: number
    },
    additionalFilters: AdditionalFilter[],
    minutesFromNow?: number,
    minDate?: string,
    maxDate?: string,
    pageShareUrl: string
}

export class GlobalFilter extends React.PureComponent<GlobalFilterProps, {}> {
    render() {
        return (
            <div className="global-filter flex">
                <MobileFilterToggle {...this.props} />
                {this.renderApplicationDropdown()}
                <StatusDropdown {...this.props} />
                <FilterBuilder {...this.props} />
                <DateRangePicker {...this.props} />
                <SavedFilters {...this.props} />
            </div>
        )
    }

    renderApplicationDropdown() {
        if (this.props.applications.length > 0 && this.props.customer.maxApplications > 0) {
            return <ApplicationDropdown {...this.props} />
        }
        else {
            return null;
        }
    }
}