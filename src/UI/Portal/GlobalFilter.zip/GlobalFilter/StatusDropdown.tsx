import * as React from "react";
import { GlobalFilterProps } from "./GlobalFilter";
import { GlobalFilterService } from "./GlobalFilterService";

interface StatusDropdownState {
    isOpen: boolean,
    appliedStatuses: string[]
}

export class StatusDropdown extends React.PureComponent<GlobalFilterProps, StatusDropdownState> {
    constructor(props: GlobalFilterProps) {
        super(props);
        this.state = {
            isOpen: false,
            appliedStatuses: props.appliedStatuses
        };
        this.dropdownRef = React.createRef();
    }

    public dropdownRef: React.RefObject<HTMLDivElement>

    componentWillMount() {
        document.addEventListener("mousedown", this.handleOutsideClick, false);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleOutsideClick, false);
    }

    render() {
        return (
            <div className={`status-dropdown filter-dropdown relative ${this.state.isOpen ? 'open' : ''}`} ref={this.dropdownRef}>
                <button type="button" className="status-name filter-dropdown-title" title={`Status: ${this.props.displayStatus}`} onClick={this.dropdownClick}>
                    <div className="flex">
                        <i className="fa fa-check-circle"></i>
                    </div>
                    <div className="flex-column">
                        <div className="flex align-center">
                            <small>STATUS</small>
                        </div>
                        <div className="flex align-center">
                            <span className="truncate-ellipsis">{this.props.displayStatus}</span>
                            <i className="fa fa-caret-down"></i>
                        </div>
                    </div>
                </button>
                <ul className="filter-dropdown-flyout" style={this.state.isOpen ? { display: "flex" } : { display: "none" }}>
                    <span className="filter-dropdown-header">
                        <a onClick={(e) => this.selectAll(e)} href="javascript:void(0);">Select All</a>
                        <a onClick={(e) => this.selectNone(e)} href="javascript:void(0);">Select None</a>
                    </span>
                    {this.renderAvailableStatuses()}
                    <span className="filter-dropdown-footer">
                        <button type="button" className="apply-status" onClick={(e) => this.applyStatusFilter()}>Apply</button>
                        {this.props.appliedStatuses.length > 0 && (
                            <a href="javascript:void(0)" className="clear-status" onClick={(e) => this.clearAllFilter(e)}>Clear All</a>
                        )}
                    </span>
                </ul>
            </div>
        )
    }

    renderAvailableStatuses() {
        var statuses = this.props.allStatuses.map(status => {
            var isSelected = this.state.appliedStatuses.indexOf(status) >= 0;
            return (
                <li key={status} className={isSelected ? "selected" : ""}>
                    <label><input type="checkbox" value={status} checked={isSelected} onChange={(e) => this.updateStatuses(e.target.checked, status)} /> {status}</label>
                </li>
            )
        });

        return statuses
    }

    dropdownClick = (evt) => {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }

    selectAll (evt){
        evt.preventDefault();
        var statuses = [...this.props.allStatuses];
        this.setState({
            appliedStatuses: statuses
        });
    }

    async selectNone(evt) {
        evt.preventDefault();
        return new Promise((resolve) => {
            this.setState({
                appliedStatuses: []
            }, resolve);
        });
    }

    async clearAllFilter(evt) {
        await this.selectNone(evt);
        await this.applyStatusFilter();
    }

    updateStatuses(isChecked: boolean, status: string) {
        if (isChecked) {
            // Ensure the status is in the applied list
            if (this.state.appliedStatuses.indexOf(status) === -1) {
                var statuses = [status].concat(this.state.appliedStatuses);
                this.setState({
                    appliedStatuses: statuses
                });
            }
        }
        else {
            // Ensure the status is NOT in the applied list
            var statuses = this.state.appliedStatuses.filter(x => x !== status);
            this.setState({
                appliedStatuses: statuses
            });
        }
    }

    applyStatusFilter = async () => {
        await GlobalFilterService.applyStatuses(this.state.appliedStatuses);
    }

    handleOutsideClick = (evt) => {
        if (!this.state.isOpen) {
            return;
        }

        if (!document.body.contains(evt.target) || this.dropdownRef.current.contains(evt.target)) {
            return;
        }
        else {
            this.setState({
                isOpen: false
            });
        }
    }
}