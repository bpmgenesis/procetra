import * as React from "react";
import { GlobalFilterProps } from "./GlobalFilter";
import { GlobalFilterService } from "./GlobalFilterService";

interface ApplicationDropdownState {
    isOpen: boolean
}

export class ApplicationDropdown extends React.PureComponent<GlobalFilterProps, ApplicationDropdownState> {
    constructor(props: GlobalFilterProps) {
        super(props);
        this.state = {
            isOpen: false
        };
        this.dropdownRef = React.createRef();
    }

    public dropdownRef: React.RefObject<HTMLDivElement>

    componentWillMount() {
        document.addEventListener("mousedown", this.handleOutsideClick, false);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleOutsideClick, false);
    }

    render() {
        return (
            <div className={`application-dropdown filter-dropdown relative ${this.state.isOpen ? 'open' : ''}`} ref={this.dropdownRef} >
                <button type="button" className="application-name filter-dropdown-title" onClick={this.dropdownClick}>
                    <div className="flex">
                        <i className="icon-applications"></i>
                    </div>
                    <div className="flex-column">
                        <div className="flex align-center">
                            <small>APPLICATION</small>
                        </div>
                        <div className="flex align-center">
                            <span className="truncate-ellipsis">{this.props.application == null ? "All" : this.props.application.name}</span>
                            <i className="fa fa-caret-down"></i>
                        </div>
                    </div>
                </button>
                <ul className="filter-dropdown-flyout" style={this.state.isOpen ? { display: "flex" } : { display: "none" }}>
                    <div className="filter-dropdown-body">
                        {this.renderAvailableApplications()}
                    </div>

                    <span className="filter-dropdown-footer">
                        <a href="/account/applications">Application Settings</a>
                    </span>
                </ul>
            </div>
        )
    }

    renderAvailableApplications() {
        var all = (
            <li key="_all" className={this.props.application == null ? "selected" : ""}>
                <a onClick={evt => this.switchApplication('', evt)} href="javascript:void(0)"><em>Show All</em></a>
            </li>
        )
        var apps = this.props.applications.map(app =>
            <li key={app.id} className={this.props.application != null && this.props.application.slug === app.slug ? "selected" : ""}>
                <a onClick={evt => this.switchApplication(app.id, evt)} href="javascript:void(0)">{app.name}</a>
            </li>
        );

        return [all].concat(apps);
    }

    dropdownClick = (evt) => {
        this.setState({
            isOpen: !this.state.isOpen
        });
    }

    switchApplication = async (id: string, evt) => {
        await GlobalFilterService.switchApplication(id);
    }

    handleOutsideClick = (evt) => {
        if (!this.state.isOpen) {
            return;
        }

        if (!document.body.contains(evt.target) || this.dropdownRef.current.contains(evt.target)) {
            return;
        }
        else {
            this.setState({
                isOpen: false
            });
        }
    }
}