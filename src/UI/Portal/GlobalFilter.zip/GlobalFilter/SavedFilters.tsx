import * as React from "react";
import { GlobalFilterService } from "./GlobalFilterService";
import { GlobalFilterProps } from "./GlobalFilter";

interface SavedFiltersState {
    isOpen: boolean,
    hasLoaded: boolean,
    savedFilters: string[],
    newFilterName: string
}

export class SavedFilters extends React.PureComponent<GlobalFilterProps, SavedFiltersState> {
    constructor(props: GlobalFilterProps) {
        super(props);
        this.state = {
            isOpen: false,
            hasLoaded: false,
            savedFilters: [],
            newFilterName: ""
        };
        this.dropdownRef = React.createRef();
    }

    public dropdownRef: React.RefObject<HTMLDivElement>

    componentWillMount() {
        document.addEventListener("mousedown", this.handleOutsideClick, false);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleOutsideClick, false);
    }

    render() {
        return (
            <div className={`saved-filters relative ${this.state.isOpen ? 'open' : ''}`} ref={this.dropdownRef}>
                <button type="button" className="saved-filters-button" title="Share or save the current filters" onClick={this.dropdownClick}>
                    <div className="flex justify-center">
                        <i className="fa fa-share-alt"></i>
                    </div>
                </button>
                <ul className="filter-dropdown-flyout" style={this.state.isOpen ? { display: "flex" } : { display: "none" }}>
                    <h4><i className="fa fa-fw fa-link"></i> Share Page</h4>
                    <div className="share-page-link flex">
                        <input type="text" readOnly value={this.props.pageShareUrl} onClick={this.selectShareUrl} />
                        <button type="button" onClick={this.copyShareUrlToClipboard}><img src="/Images/onboarding/copy.svg" /></button>
                    </div>
                    <h4><i className="fa fa-fw fa-bookmark"></i> Saved Filters</h4>
                    <div className="filter-list flex-column">
                        {this.renderSavedFilters()}
                    </div>
                    <form onSubmit={this.saveFilter}>
                    <span className="save-your-filter filter-dropdown-footer flex-column">
                            <h4>Save your current filter:</h4>
                            <input type="text" maxLength={100} value={this.state.newFilterName} placeholder="Enter filter name" onChange={this.onNameTextChange} />
                            <button type="submit" className="save-filters">Save</button>
                    </span>
                    </form>
                </ul>
            </div>
        )
    }

    renderSavedFilters() {
        if (this.state.savedFilters.length == 0) {
            return (
                <li key="none" className="no-filters"><span>No Saved Filters</span></li>
            )
        }

        var savedFilterMarkup = this.state.savedFilters.map(filterName => {
            return (
                <li key={filterName} className="saved-filter" onClick={evt => this.applyFilter(filterName)}>
                    <i className="fa fa-bookmark" />
                    <span className="filter-name">{filterName}</span>
                    <button className="delete-filter" type="button" onClick={(evt) => this.deleteFilter(evt, filterName)}><i className="fa fa-trash"></i></button>
                </li>
            )
        });

        return savedFilterMarkup;
    }

    dropdownClick = (evt) => {
        this.setState({
            isOpen: !this.state.isOpen
        });

        if (!this.state.hasLoaded) {
            this.loadSavedFilters();
        }
    }

    async loadSavedFilters() {
        var savedFilters = await GlobalFilterService.getSavedFilters();

        this.setState({
            savedFilters: savedFilters,
            hasLoaded: true
        });
    }

    async applyFilter(filterName: string) {
        await GlobalFilterService.applySavedFilter(filterName);
        window.pjaxReload();
    }

    async deleteFilter(evt, filterName: string) {
        evt.preventDefault();
        evt.stopPropagation();
        var shouldDelete = confirm(`Are you sure you want to delete ${filterName}?`);
        if (shouldDelete) {
            await GlobalFilterService.deleteSavedFilter(filterName);
            await this.loadSavedFilters();
        }
    }

    onNameTextChange = (evt) => {
        var newFilterName = evt.target.value;
        this.setState({ newFilterName: newFilterName });
    }

    saveFilter = async (evt) => {
        evt.preventDefault();
        if (!this.state.newFilterName) {
            return;
        }

        if (this.state.savedFilters.find(x => x.toLowerCase() === this.state.newFilterName.toLowerCase())) {
            var shouldReplace = confirm(`Saving filter ${this.state.newFilterName} will replace the existing filter.  Do you want to continue?`);
            if (!shouldReplace) {
                return;
            }
        }

        await GlobalFilterService.saveCurrentFilter(this.state.newFilterName);
        await this.loadSavedFilters();
        this.setState({ newFilterName: "" });
    }

    selectShareUrl = (evt) => {
        // Tries to select the value inside the textbox for more easy copy/paste.
        evt.currentTarget.select();
    }

    copyShareUrlToClipboard = () => {
        window.trackUi.copyToClipboard(this.props.pageShareUrl);
    }

    handleOutsideClick = (evt) => {
        if (!this.state.isOpen) {
            return;
        }

        if (!document.body.contains(evt.target) || this.dropdownRef.current.contains(evt.target)) {
            return;
        }
        else {
            this.setState({
                isOpen: false
            });
        }
    }
}