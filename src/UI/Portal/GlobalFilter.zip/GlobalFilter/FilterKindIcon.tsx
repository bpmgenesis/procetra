import * as React from "react";
import { AdditionalFilter } from "./FilterStore";

export function FilterKindIcon(props: { filter: AdditionalFilter }) {
    var filter = props.filter;
    var isFilterSearch = /search/ig.test(filter.type);
    var isNegated = filter.isNegated;
    return (
        <span className="filter-kind">
            {isFilterSearch && !isNegated && <i className="fa fa-search"></i>}
            {!isFilterSearch && !isNegated && <i className="">=</i>}
            {isFilterSearch && isNegated && <i className="fa fa-search-minus"></i>}
            {!isFilterSearch && isNegated && <i>≠</i>}
        </span>
    )
}