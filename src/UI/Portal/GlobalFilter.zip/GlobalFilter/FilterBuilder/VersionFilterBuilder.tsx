import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { RecentlyViewed } from "../RecentlyViewed";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { FilterKindIcon } from "../FilterKindIcon";
import { appliedFilterSort } from "./appliedFilterSort";

export interface VersionFilterBuilderState {
    topVersions: { Key: string, Value: number }[]
    topVersionsLoading: boolean
}

interface VersionFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class VersionFilterBuilder extends React.PureComponent<VersionFilterBuilderProps, VersionFilterBuilderState> {

    constructor(props) {
        super(props);
        this.state = {
            topVersions: null,
            topVersionsLoading: false
        }
        this.autocompleteRef = React.createRef();
    }

    autocompleteRef: RefObject<FilterAutocomplete>;

    componentDidUpdate(prevProps: VersionFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.topVersionsLoading) {
            this.setState({ topVersionsLoading: true });
            this.fetchTopVersions();
        }
    }

    render() {
        var versionFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Version);
        var recentVersions = this.renderRecentVersions();
        var topVersions = this.renderTopVersions();
        var noQuickFilters = null;
        if (recentVersions === null && topVersions === null) {
            noQuickFilters = <h4 className="no-quick-filters">Sorry, there are no quick version filters available</h4>;
        }
        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>Version Filters</h4>
                    <hr />
                    {this.renderVersionFilters(versionFilters)}
                    <FilterAutocomplete ref={this.autocompleteRef} additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.Version} />
                </div>
                <div className="quick-filters">
                    {topVersions}
                    {recentVersions}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderVersionFilters(versionFilters: AdditionalFilter[]) {
        if (!versionFilters || versionFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Version Filters</span>
        }
        versionFilters = versionFilters.sort(appliedFilterSort);
        var renderedVersionFilters = versionFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" onClick={() => this.autocompleteRef.current.onAutocompleteTextChange(filter.rawValue)} title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedVersionFilters;
    }

    renderRecentVersions() {
        var recentVersions = RecentlyViewed.recentVersions.filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Version).find(y => x === y.rawValue));
        if (recentVersions.length > 0) {
            return (
                <div className="recent-versions">
                    <h4>Recently Viewed Versions</h4>
                    <hr />
                    {
                        recentVersions.map(x => {
                            return (
                                <div className="flex filter-item" key={x} onClick={e => this.addFilter(e, "version", x)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x}> {x}</span>
                                        <span className="add-filter" title="Includes all errors from this version">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "version", x, true)} title="Excludes all errors from this version">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    renderTopVersions() {
        var topVersions = (this.state.topVersions || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Version).find(y => x.Key === y.rawValue));
        topVersions = topVersions.slice(0, 5);
        if (topVersions.length > 0 || this.state.topVersionsLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Versions  <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.topVersionsLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.topVersionsLoading &&
                        topVersions.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "version", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.Key}>{x.Key}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this version">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "version", x.Key, true)} title="Excludes all errors from this version">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    addFilter(evt, filterType: string, filterValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter = {
            type: filterType,
            displayKey: "Version",
            displayValue: filterValue,
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchTopVersions() {
        var topVersions = await GlobalFilterService.getVersionFilterTopVersions(FilterStore.getState());
        this.setState({
            topVersions: topVersions,
            topVersionsLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }

}