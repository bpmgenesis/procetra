import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { FilterKindIcon } from "../FilterKindIcon";
import { appliedFilterSort } from "./appliedFilterSort";

export interface StackTraceFilterBuilderState { }

interface StackTraceFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class StackTraceFilterBuilder extends React.PureComponent<StackTraceFilterBuilderProps, StackTraceFilterBuilderState> {

    constructor(props: StackTraceFilterBuilderProps) {
        super(props);
        this.state = {};
        this.autocompleteRef = React.createRef();
    }

    autocompleteRef: RefObject<FilterAutocomplete>;

    render() {
        var StackTraceFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.StackTrace);

        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>Stack Trace Filters</h4>
                    <hr />
                    {this.renderStackTraceFilters(StackTraceFilters)}
                    <FilterAutocomplete ref={this.autocompleteRef} additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.StackTrace} />
                </div>
                <div className="quick-filters">
                </div>
            </div>
        )
    }

    renderStackTraceFilters(StackTraceFilters: AdditionalFilter[]) {
        if (!StackTraceFilters || StackTraceFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Stack Trace Filters</span>
        }
        StackTraceFilters = StackTraceFilters.sort(appliedFilterSort);

        var renderedFilters = StackTraceFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" onClick={() => this.autocompleteRef.current.onAutocompleteTextChange(filter.rawValue)} title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedFilters;
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }

}