import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { RecentlyViewed } from "../RecentlyViewed";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { stripDelimiter } from "./stripDelimiter";
import { FilterKindIcon } from "../FilterKindIcon";
import { appliedFilterSort } from "./appliedFilterSort";

export interface BrowserFilterBuilderState {
    topBrowsers: { Key: string, Value: number }[]
    topBrowsersLoading: boolean
}

interface BrowserFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class BrowserFilterBuilder extends React.PureComponent<BrowserFilterBuilderProps, BrowserFilterBuilderState> {

    constructor(props) {
        super(props);
        this.state = {
            topBrowsers: null,
            topBrowsersLoading: false
        }
        this.autocompleteRef = React.createRef();
    }

    autocompleteRef: RefObject<FilterAutocomplete>;

    componentDidUpdate(prevProps: BrowserFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.topBrowsersLoading) {
            this.setState({ topBrowsersLoading: true });
            this.fetchTopBrowsers();
        }
    }

    render() {
        var browserFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Browser);
        var recentBrowsers = this.renderRecentBrowsers()
        var topBrowsers = this.renderTopBrowsers()
        var noQuickFilters = null;
        if (recentBrowsers === null && topBrowsers === null) {
            noQuickFilters =  <h4 className="no-quick-filters">Sorry, there are no quick browser filters available</h4>;
        }

        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>Browser Filters</h4>
                    <hr />
                    {this.renderBrowserFilters(browserFilters)}
                    <FilterAutocomplete ref={this.autocompleteRef} additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.Browser} />
                </div>
                <div className="quick-filters">
                    {topBrowsers}
                    {recentBrowsers}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderBrowserFilters(browserFilters: AdditionalFilter[]) {
        if (!browserFilters || browserFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Browser Filters</span>
        }
        browserFilters = browserFilters.sort(appliedFilterSort);
        var renderedBrowserFilters = browserFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" onClick={() => this.autocompleteRef.current.onAutocompleteTextChange(stripDelimiter(filter.rawValue))} title={filter.displayValue} > {stripDelimiter(filter.displayValue)}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedBrowserFilters;
    }

    renderRecentBrowsers() {
        var recentBrowsers = RecentlyViewed.recentBrowsers.filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Browser).find(y => x === y.rawValue));
        if (recentBrowsers.length > 0 || this.state.topBrowsersLoading) {
            return (
                <div className="recent-browsers">
                    <h4>Recent Browsers</h4>
                    <hr />
                    {
                        recentBrowsers.map(x => {
                            return (
                                <div className="flex filter-item" key={x} onClick={e => this.addFilter(e, "browser", x)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={stripDelimiter(x)}> {stripDelimiter(x)}</span>
                                        <span className="add-filter" title="Includes all errors from this browser">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "browser", x, true)} title="Excludes all errors from this browser">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    renderTopBrowsers() {
        var topBrowsers = (this.state.topBrowsers || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Browser).find(y => x.Key === y.rawValue));
        topBrowsers = topBrowsers.slice(0, 5);
        if (topBrowsers.length > 0 || this.state.topBrowsersLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Browsers  <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.topBrowsersLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.topBrowsersLoading &&
                        topBrowsers.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "browser", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={stripDelimiter(x.Key)}>{stripDelimiter(x.Key)}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this browser" >
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "browser", x.Key, true)} title="Excludes all errors from this browser">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    addFilter(evt, filterType: string, filterValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter: AdditionalFilter = {
            type: filterType,
            displayKey: "Browser",
            displayValue: stripDelimiter(filterValue),
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchTopBrowsers() {
        var topBrowsers = await GlobalFilterService.getBrowserFilterTopBrowsers(FilterStore.getState());
        this.setState({
            topBrowsers: topBrowsers,
            topBrowsersLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }

}