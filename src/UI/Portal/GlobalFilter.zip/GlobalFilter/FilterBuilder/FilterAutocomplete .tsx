import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { debounce } from "./debounce";
import { GlobalFilterService, AutocompleteResult } from "../GlobalFilterService";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { stripDelimiter } from "./stripDelimiter";

export interface FilterAutocompleteState {
    autocompleteText: string
    autocompleteResults: RenderableAutocompleteResult[]
    autocompleteIsRunning: boolean
    autocompleteIsVisible: boolean
    autocompleteSelectedIndex: number
}

type RenderableAutocompleteResult = {
    Text: string
    Count: number
    FilterType: string
    Kind: string
}

interface FilterAutocompleteProps {
    additionalFilters: AdditionalFilter[];
    filterBuilderTab: SelectedFilterBuilderTab
}

export class FilterAutocomplete extends React.PureComponent<FilterAutocompleteProps, FilterAutocompleteState> {
    constructor(props) {
        super(props);
        this.state = {
            autocompleteText: "",
            autocompleteResults: null,
            autocompleteIsRunning: false,
            autocompleteIsVisible: false,
            autocompleteSelectedIndex: -1,
        }

        this.applyAutocompleteTabSettings(this.props.filterBuilderTab);

        this.autocompleteRef = React.createRef();
        this.doAutocomplete = debounce(this.doAutocomplete, 300);
    }

    public autocompleteRef: React.RefObject<HTMLDivElement>
    private exactFilterType: string
    private searchFilterType: string
    private fetchAutocompleteResults: (text: string, proposedFilters: AdditionalFilter[]) => Promise<AutocompleteResult>
    private filterTypeDisplayKey: string
    private placeholderText: string

    componentWillMount() {
        document.addEventListener("mousedown", this.handleAutocompleteOutsideClick, false);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleAutocompleteOutsideClick, false);
    }

    render() {
        return (
            <div className="add-new-filter" ref={this.autocompleteRef}>
                <input type="text"
                    placeholder={`${this.placeholderText}`}
                    value={this.state.autocompleteText}
                    onChange={e => this.onAutocompleteTextChange(e.target.value)}
                    onFocus={e => this.setState({
                        autocompleteIsVisible: true
                    })}
                    onKeyDown={e => this.autoCompleteKeyDown(e)}
                />
                <div className="autocomplete-results">
                    {this.renderAutocompleteResults()}
                </div>
            </div>
        )
    }

    renderAutocompleteResults() {
        var results = this.state.autocompleteResults;

        if (this.state.autocompleteIsRunning) {
            return <span>Loading...</span>
        }

        if (!this.state.autocompleteIsVisible) {
            return null;
        }

        if (results && results.length > 0) {

            var markup = [];
            results.forEach((result, idx) => {
                var selectedClass = this.state.autocompleteSelectedIndex === idx ? "selected" : "";
                var title = this.getResultTitle(result);
                markup.push(
                    <div className={`autocomplete-result ${selectedClass}`} title={title} key={result.Text}
                        onClick={e => this.addAutocompleteFilter(e, result)}>
                        <span className="result-kind exact">{this.getResultKind(result)}</span>
                        {this.props.filterBuilderTab !== SelectedFilterBuilderTab.Metadata &&
                            <span className="result-text">{stripDelimiter(result.Text)}</span>
                        }
                        {this.props.filterBuilderTab === SelectedFilterBuilderTab.Metadata &&
                            <span className="result-text">{stripDelimiter(result.Text, ": ")}</span>
                        }
                        <span className="result-count">{result.Count.toLocaleString()}</span>
                        <span className="add-filter" title="Include all errors that match this value">
                            <i className="fa fa-plus-circle"></i>
                        </span>
                        <span className="negate-filter" title="Exclude all errors that match this value" onClick={e => this.addAutocompleteFilter(e, result, true)}>
                            <i className="fa fa-minus-circle"></i>
                        </span>
                    </div>
                )
            });

            return markup;
        }
        else if (results && results.length === 0) {
            return <span>No Results</span>
        }
        else {
            return null;
        }
    }


    private getResultTitle(result: RenderableAutocompleteResult): string {
        var title = "";
        var isFilterSearch = /search/ig.test(result.Kind);
        if (isFilterSearch) {
            title = `Search ${this.exactFilterType}s for query: ${stripDelimiter(result.Text)}`;
        }
        else {
            if (this.props.filterBuilderTab === SelectedFilterBuilderTab.Metadata) {
                title = `Filter to ${stripDelimiter(result.Text, ": ")}`;
            }
            else {
                title = `Filter to ${this.exactFilterType}s that exactly match: ${stripDelimiter(result.Text)}`;
            }
        }
        return title;
    }

    private getResultKind(result: RenderableAutocompleteResult): string {
        if (result.FilterType === "stacktraceSearch") {
            return "Contains";
        }
        else {
            return result.Kind;
        }
    }

    autoCompleteKeyDown(e: React.KeyboardEvent<HTMLInputElement>): any {
        if (!this.state.autocompleteResults || this.state.autocompleteResults.length === 0) {
            return;
        }
        if (e.keyCode === 38) { // up
            this.setState({
                autocompleteSelectedIndex: Math.max(this.state.autocompleteSelectedIndex - 1, -1)
            });
        }
        else if (e.keyCode === 40) { // down
            this.setState({
                autocompleteSelectedIndex: Math.min(this.state.autocompleteSelectedIndex + 1, this.state.autocompleteResults.length - 1)
            });
        }
        else if (e.keyCode === 27) { // esc
            e.nativeEvent.stopImmediatePropagation();

            this.setState({
                autocompleteIsVisible: false
            });
        }
        else if (e.keyCode === 13) { // enter
            var selectedResult = this.state.autocompleteResults[this.state.autocompleteSelectedIndex];
            if (!selectedResult) {
                selectedResult = this.state.autocompleteResults[0];
                if (selectedResult.Kind === "Search" || selectedResult.Text === this.state.autocompleteText) {
                    this.addAutocompleteFilter(e, selectedResult);
                }
            }
            else {
                this.addAutocompleteFilter(e, selectedResult);
            }
        }
    }

    addAutocompleteFilter(evt, selectedResult: RenderableAutocompleteResult, isNegated = false) {
        evt.stopPropagation();
        this.addFilter(selectedResult.FilterType, selectedResult.Text, isNegated);
        this.setState({
            autocompleteText: "",
            autocompleteResults: this.state.autocompleteResults.filter(x => x !== selectedResult),
            autocompleteSelectedIndex: -1,
            autocompleteIsVisible: false
        });
    }

    addFilter(filterType: string, filterValue: string, isNegated = false): any {
        var additionalFilter: AdditionalFilter = {
            type: filterType,
            displayKey: this.filterTypeDisplayKey,
            displayValue: stripDelimiter(filterValue),
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    onAutocompleteTextChange(text: string) {
        this.setState({
            autocompleteText: text,
            autocompleteIsVisible: true
        });
        this.doAutocomplete(text);
    }

    async doAutocomplete(text: string) {
        if (!text) {
            this.setState({ autocompleteResults: null })
            return;
        }
        this.setState({
            autocompleteIsRunning: true
        });
        var autocompleteResults = await this.fetchAutocompleteResults(text, FilterStore.getState());
        var existingFilters = this.props.additionalFilters.filter(x => x.type === this.exactFilterType || x.type === this.searchFilterType);
        var searchExists = !!existingFilters.find(x => x.type === this.searchFilterType && x.rawValue === autocompleteResults.Query)
        var exactMatch = autocompleteResults.ExactValues.find(x => x.Key === this.state.autocompleteText && !existingFilters.find(y => y.rawValue === x.Key));
        var nonExactMatches = autocompleteResults.ExactValues.filter(x => x.Key !== this.state.autocompleteText && !existingFilters.find(y => y.rawValue === x.Key));
        var renderableResults: RenderableAutocompleteResult[] = [];
        if (exactMatch) {
            renderableResults.push({
                Text: exactMatch.Key,
                Count: exactMatch.Value,
                FilterType: exactMatch.FilterTypeOverride || this.exactFilterType,
                Kind: exactMatch.FilterTypeOverride || "Exact"
            });
        }
        if (!searchExists && autocompleteResults.Query) {
            renderableResults.push({
                Text: autocompleteResults.Query,
                Count: autocompleteResults.SearchResultCount,
                FilterType: this.searchFilterType,
                Kind: "Search"
            });
        }

        nonExactMatches.forEach(nem => renderableResults.push({
            Text: nem.Key,
            Count: nem.Value,
            FilterType: nem.FilterTypeOverride || this.exactFilterType,
            Kind: nem.FilterTypeOverride || "Exact"
        }));

        this.setState({
            autocompleteResults: renderableResults,
            autocompleteIsRunning: false
        });
    }

    handleAutocompleteOutsideClick = (evt) => {
        if (!document.body.contains(evt.target) || this.autocompleteRef.current.contains(evt.target)) {
            return;
        }
        else {
            this.setState({
                autocompleteIsVisible: false
            });
        }
    }

    applyAutocompleteTabSettings(selectedTab: SelectedFilterBuilderTab) {
        switch (selectedTab) {
            case SelectedFilterBuilderTab.Error:
                this.exactFilterType = "message";
                this.searchFilterType = "messageSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getMessageFilterAutocomplete;
                this.filterTypeDisplayKey = "Message";
                this.placeholderText = "Enter all or part of an error message to create a new filter";
                break;
            case SelectedFilterBuilderTab.Browser:
                this.exactFilterType = "browser";
                this.searchFilterType = "browserSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getBrowserFilterAutocomplete;
                this.filterTypeDisplayKey = "Browser";
                this.placeholderText = "Enter a browser name or version to create a new filter";
                break;
            case SelectedFilterBuilderTab.Users:
                this.exactFilterType = "user";
                this.searchFilterType = "userSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getUserFilterAutocomplete;
                this.filterTypeDisplayKey = "User";
                this.placeholderText = "Enter a user ID to create a new filter";
                break;
            case SelectedFilterBuilderTab.Version:
                this.exactFilterType = "version";
                this.searchFilterType = "versionSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getVersionFilterAutocomplete;
                this.filterTypeDisplayKey = "Version";
                this.placeholderText = "Enter a version identifier to create a new filter";
                break;
            case SelectedFilterBuilderTab.Metadata:
                this.exactFilterType = "metadata";
                this.searchFilterType = null;
                this.fetchAutocompleteResults = GlobalFilterService.getMetadataFilterAutocomplete;
                this.filterTypeDisplayKey = "Metadata";
                this.placeholderText = "Enter metadata values or keys to create a new filter";
                break;
            case SelectedFilterBuilderTab.Domain:
                this.exactFilterType = "domain";
                this.searchFilterType = "urlSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getDomainAutocomplete;
                this.filterTypeDisplayKey = "Domain";
                this.placeholderText = "Enter all or part of a domain to create a filter";
                break;
            case SelectedFilterBuilderTab.StackTrace:
                this.exactFilterType = "stacktraceSearch";
                this.searchFilterType = "stacktraceSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getStackTraceFilterAutocomplete;
                this.filterTypeDisplayKey = "Stack Trace";
                this.placeholderText = "Enter part of a stack trace to create a filter";
                break;
            case SelectedFilterBuilderTab.IpAddress:
                this.exactFilterType = "ip";
                this.searchFilterType = "ipSearch";
                this.fetchAutocompleteResults = GlobalFilterService.getIpAddressFilterAutocomplete;
                this.filterTypeDisplayKey = "IP Address";
                this.placeholderText = "Enter all or part of an IP address to create a filter";
                break;
            default:
                throw new Error("Cannot find configuration for our dope ass autocomplete");
        }
    }
}

