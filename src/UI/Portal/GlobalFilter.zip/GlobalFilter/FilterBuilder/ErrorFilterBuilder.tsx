import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { RecentlyViewed } from "../RecentlyViewed";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { FilterKindIcon } from "../FilterKindIcon";
import { appliedFilterSort } from "./appliedFilterSort";

export interface ErrorFilterBuilderState {
    topMessages: { Key: string, Value: number }[]
    topMessagesLoading: boolean
    stacktraceFilter: AdditionalFilter
}

interface ErrorFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class ErrorFilterBuilder extends React.PureComponent<ErrorFilterBuilderProps, ErrorFilterBuilderState> {

    constructor(props: ErrorFilterBuilderProps) {
        super(props);
        this.state = {
            topMessages: null,
            topMessagesLoading: false,
            stacktraceFilter: props.additionalFilters.find(x => x.type === "stacktrace")
        }
        this.autocompleteRef = React.createRef();
    }

    autocompleteRef: RefObject<FilterAutocomplete>;

    componentDidUpdate(prevProps: ErrorFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.topMessagesLoading) {
            this.setState({ topMessagesLoading: true });
            this.fetchTopMessages();
        }
    }

    render() {
        var messageFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Error);
        var recentMessages = this.renderRecentMessages();
        var topMessages = this.renderTopMessages();
        var noQuickFilters = null;
        if (recentMessages === null && topMessages === null) {
            noQuickFilters = <h4 className="no-quick-filters">Sorry, there are no quick error message filters available</h4>;
        }
        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>Error Message Filters</h4>
                    <hr />
                    {this.renderMessageFilters(messageFilters)}
                    <FilterAutocomplete ref={this.autocompleteRef} additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.Error} />
                    <label className="flex align-center filter-item">
                        <input type="checkbox" checked={!!this.state.stacktraceFilter} onChange={(e) => this.stacktraceOnlyChecked(e)} style={{ marginTop: 0 }} />
                        <span style={{ marginLeft: "4px" }}>Include Only Errors With Stack Trace</span>
                    </label>
                </div>
                <div className="quick-filters">
                    {topMessages}
                    {recentMessages}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderMessageFilters(messageFilters: AdditionalFilter[]) {
        if (!messageFilters || messageFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Error Message Filters</span>
        }
        messageFilters = messageFilters.sort(appliedFilterSort);

        var renderedMessageFilters = messageFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" onClick={() => this.autocompleteRef.current.onAutocompleteTextChange(filter.rawValue)} title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedMessageFilters;
    }

    renderRecentMessages() {
        var recentMessages = RecentlyViewed.recentMessages.filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Error).find(y => x === y.rawValue));

        if (recentMessages.length > 0) {
            return (
                <div className="recent-messages">
                    <h4>Recently Viewed Errors</h4>
                    <hr />
                    {
                        recentMessages.map(x => {
                            return (
                                <div className="flex filter-item" key={x} onClick={e => this.addFilter(e, "message", x)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x}> {x}</span>
                                        <span className="add-filter" title="Includes all errors with this message">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "message", x, true)} title="Excludes all errors with this message">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    renderTopMessages() {
        var topMessages = (this.state.topMessages || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Error).find(y => x.Key === y.rawValue));
        topMessages = topMessages.slice(0, 5);
        if (topMessages.length > 0 || this.state.topMessagesLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Errors <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.topMessagesLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.topMessagesLoading &&
                        topMessages.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "message", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.Key}>{x.Key}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors with this message">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "message", x.Key, true)} title="Excludes all errors with this message">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    addFilter(evt, filterType: string, filterValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter: AdditionalFilter = {
            type: filterType,
            displayKey: "Message",
            displayValue: filterValue,
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchTopMessages() {
        var topMessages = await GlobalFilterService.getMessageFilterTopMessages(FilterStore.getState());
        this.setState({
            topMessages: topMessages,
            topMessagesLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }

    stacktraceOnlyChecked(evt: React.ChangeEvent) {
        if (this.state.stacktraceFilter) {
            FilterStore.removeFilter(this.state.stacktraceFilter);
            this.setState({
                stacktraceFilter: null
            });
        }
        else {
            var filter = {
                type: "stacktrace",
                displayKey: "Stack Trace",
                displayValue: "Yes",
                rawValue: "Yes",
                isNegated: false
            };
            FilterStore.addFilter(filter);
            this.setState({
                stacktraceFilter: filter
            });
        }
    }

}