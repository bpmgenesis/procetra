import { AdditionalFilter } from "../FilterStore";

export function appliedFilterSort(a: AdditionalFilter, b: AdditionalFilter) {
    if (a.isNegated != b.isNegated) {
        return a.isNegated ? 1 : -1;
    }
    return a.rawValue >= b.rawValue ? 1 : -1
}