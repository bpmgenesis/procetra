export function stripDelimiter(value: string, replacementStr = " ") {
    if (value) {
        value = value.replace("~~~", replacementStr);
    }

    return value;
}