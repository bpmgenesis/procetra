import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { RecentlyViewed } from "../RecentlyViewed";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { FilterKindIcon } from "../FilterKindIcon";
import { appliedFilterSort } from "./appliedFilterSort";

export interface UserFilterBuilderState {
    topUsers: { Key: string, Value: number }[]
    topUsersLoading: boolean
}

interface UserFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class UserFilterBuilder extends React.PureComponent<UserFilterBuilderProps, UserFilterBuilderState> {

    constructor(props) {
        super(props);
        this.state = {
            topUsers: null,
            topUsersLoading: false
        }
        this.autocompleteRef = React.createRef();
    }

    autocompleteRef: RefObject<FilterAutocomplete>;

    componentDidUpdate(prevProps: UserFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.topUsersLoading) {
            this.setState({ topUsersLoading: true });
            this.fetchTopUsers();
        }
    }

    render() {
        var userFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Users);
        var recentUsers = this.renderRecentUsers();
        var topUsers = this.renderTopUsers();
        var noQuickFilters = null;
        if (recentUsers === null && topUsers === null) {
            noQuickFilters = <h4 className="no-quick-filters">Sorry, there are no quick user filters available</h4>;
        }
        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>User Filters</h4>
                    <hr />
                    {this.renderUserFilters(userFilters)}
                    <FilterAutocomplete ref={this.autocompleteRef} additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.Users} />
                </div>
                <div className="quick-filters">
                    {topUsers}
                    {recentUsers}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderUserFilters(userFilters: AdditionalFilter[]) {
        if (!userFilters || userFilters.length === 0) {
            return <span className="no-filters">No Currently Applied User User Filters</span>
        }
        userFilters = userFilters.sort(appliedFilterSort);
        var renderedUserFilters = userFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" onClick={() => this.autocompleteRef.current.onAutocompleteTextChange(filter.rawValue)} title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedUserFilters;
    }

    renderRecentUsers() {
        var recentUsers = RecentlyViewed.recentUsers.filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Users).find(y => x === y.rawValue));
        if (recentUsers.length > 0) {
            return (
                <div className="recent-users">
                    <h4>Recently Viewed Users</h4>
                    <hr />
                    {
                        recentUsers.map(x => {
                            return (
                                <div className="flex filter-item" key={x} onClick={e => this.addFilter(e, "user", x)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x}> {x}</span>
                                        <span className="add-filter" title="Includes all errors from this user ID">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "user", x, true)} title="Excludes all errors from this user ID">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    renderTopUsers() {
        var topUsers = (this.state.topUsers || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Users).find(y => x.Key === y.rawValue));
        topUsers = topUsers.slice(0, 5);
        if (topUsers.length > 0 || this.state.topUsersLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Users  <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.topUsersLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.topUsersLoading &&
                        topUsers.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "user", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.Key}>{x.Key}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this user ID">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "user", x.Key, true)} title="Excludes all errors from this user ID">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

     addFilter(evt, filterType: string, filterValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter = {
            type: filterType,
            displayKey: "User",
            displayValue: filterValue,
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchTopUsers() {
        var topUsers = await GlobalFilterService.getUserFilterTopUsers(FilterStore.getState());
        this.setState({
            topUsers: topUsers,
            topUsersLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }

}