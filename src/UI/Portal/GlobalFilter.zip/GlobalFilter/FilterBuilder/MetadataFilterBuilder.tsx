import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { stripDelimiter } from "./stripDelimiter";
import { appliedFilterSort } from "./appliedFilterSort";
import { FilterKindIcon } from "../FilterKindIcon";

export interface MetadataFilterBuilderState {
    topMetadata: { Key: string, Value: number }[]
    topMetadataLoading: boolean
}

interface MetadataFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class MetadataFilterBuilder extends React.PureComponent<MetadataFilterBuilderProps, MetadataFilterBuilderState> {

    constructor(props) {
        super(props);
        this.state = {
            topMetadata: null,
            topMetadataLoading: false
        }
        this.autocompleteRef = React.createRef();
    }

    autocompleteRef: RefObject<FilterAutocomplete>;

    componentDidUpdate(prevProps: MetadataFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.topMetadataLoading) {
            this.setState({ topMetadataLoading: true });
            this.fetchTopMetadata();
        }
    }

    render() {
        var metadataFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Metadata);
        var topMetadata = this.renderTopMetadata();
        var noQuickFilters = null;
        if (topMetadata === null) {
            noQuickFilters = <h4 className="no-quick-filters">Sorry, there are no quick metadata filters available</h4>;
        }
        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>Metadata Filters</h4>
                    <hr />
                    {this.renderMetadataFilters(metadataFilters)}
                    <FilterAutocomplete ref={this.autocompleteRef} additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.Metadata} />
                </div>
                <div className="quick-filters">
                    {topMetadata}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderMetadataFilters(metadataFilters: AdditionalFilter[]) {
        if (!metadataFilters || metadataFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Metadata Filters</span>
        }
        metadataFilters = metadataFilters.sort(appliedFilterSort);
        var prevFilter: AdditionalFilter = null, nextFilter: AdditionalFilter = null;
        var renderedMetadataFilters = metadataFilters.map((filter, idx) => {
            var isOr = false, isAnd = false, isAndSpacer = false, isBigMargin = false, isSmallMargin = false;
            var currentKey = filter.rawValue.split("~~~")[0];
            if (prevFilter) {
                var prevKey = prevFilter.rawValue.split("~~~")[0];
                if (filter.isNegated) {
                    isAnd = true;
                    if (prevFilter.isNegated) {
                        isSmallMargin = true;
                    }
                    else {
                        isBigMargin = true;
                    }
                }
                else if (prevKey === currentKey) {
                    isOr = true;
                    isSmallMargin = true;
                }
                else if (prevKey !== currentKey) {
                    isAndSpacer = true;
                    isBigMargin = true;
                }
            }
            prevFilter = filter;

            var style = {};
            if (isBigMargin) {
                style["marginTop"] = "18px";
            }
            else if (isSmallMargin) {
                style["marginTop"] = "5px";
            }
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue} style={style}>
                    {isOr && <span className="or-spacer">or</span>}
                    {isAnd && <span className="and">and</span>}
                    {isAndSpacer && <span className="and-spacer">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text"
                            title={stripDelimiter(filter.rawValue, ": ")}>{stripDelimiter(filter.rawValue, ": ")}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedMetadataFilters;
    }

    renderTopMetadata() {
        var topMetadata = (this.state.topMetadata || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Metadata).find(y => x.Key === y.rawValue));
        topMetadata = topMetadata.slice(0, 8);
        if (topMetadata.length > 0 || this.state.topMetadataLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Metadata  <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.topMetadataLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.topMetadataLoading &&
                        topMetadata.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "metadata", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.Key}>{stripDelimiter(x.Key, ": ")}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors with this key/value pair">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "metadata", x.Key, true)} title="Excludes all errors with this key/value pair">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    addFilter(evt, filterType: string, filterValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter: AdditionalFilter = {
            type: filterType,
            displayKey: "Metadata",
            displayValue: filterValue,
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchTopMetadata() {
        var topMetadata = await GlobalFilterService.getMetadataFilterTopMetadata(FilterStore.getState());
        this.setState({
            topMetadata: topMetadata,
            topMetadataLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }

}