import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { FilterAutocomplete } from "./FilterAutocomplete";
import { appliedFilterSort } from "./appliedFilterSort";
import { FilterKindIcon } from "../FilterKindIcon";

export interface DomainFilterBuilderState {
    availableDomains: { Key: string, Value: number }[]
    availableDomainsLoading: boolean
    topUrls: { Key: string, Value: number }[]
}

interface DomainFilterBuilderProps {
    additionalFilters: AdditionalFilter[]
    isVisible: boolean
}

export class DomainFilterBuilder extends React.PureComponent<DomainFilterBuilderProps, DomainFilterBuilderState> {

    constructor(props) {
        super(props);
        this.state = {
            availableDomains: [],
            topUrls: [],
            availableDomainsLoading: false
        };
    }

    componentDidUpdate(prevProps: DomainFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.availableDomainsLoading) {
            this.setState({ availableDomainsLoading: true });
            this.fetchDomains();
        }
    }

    render() {
        var domainFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Domain);
        var availableDomains = this.renderAvailableDomains();
        var topUrls = this.renderTopUrls();
        var noQuickFilters = null;
        if (availableDomains === null && topUrls === null) {
            noQuickFilters = <h4 className="no-quick-filters">Sorry, there are no quick url filters available</h4>;
        }
        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <h4>Urls</h4>
                    <hr />
                    {this.renderDomainFilters(domainFilters)}
                    <FilterAutocomplete additionalFilters={this.props.additionalFilters} filterBuilderTab={SelectedFilterBuilderTab.Domain} />
                </div>
                <div className="quick-filters">
                    {topUrls}
                    {availableDomains}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderDomainFilters(domainFilters: AdditionalFilter[]) {
        if (!domainFilters || domainFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Url Filters</span>
        }
        domainFilters = domainFilters.sort(appliedFilterSort);
        var renderedDomainFilters = domainFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedDomainFilters;
    }

    renderAvailableDomains() {
        var topDomains = (this.state.availableDomains || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Domain).find(y => x.Key === y.rawValue));
        topDomains = topDomains.slice(0, 4);
        if (topDomains.length > 0 || this.state.availableDomainsLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Domains</h4>
                    <hr />
                    {this.state.availableDomainsLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.availableDomainsLoading &&
                        topDomains.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "domain", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.Key}>{x.Key}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this domain">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "domain", x.Key, true)} title="Excludes all errors from this domain">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    renderTopUrls() {
        var topUrls = (this.state.topUrls || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Domain).find(y => x.Key === y.rawValue));
        topUrls = topUrls.slice(0, 4);
        if (topUrls.length > 0 || this.state.availableDomainsLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Urls  <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.availableDomainsLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.availableDomainsLoading &&
                        topUrls.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "url", x.Key)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.Key}>{x.Key}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this url">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "url", x.Key, true)} title="Excludes all errors from this url">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    addFilter(evt, filterType: string, filterValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter = {
            type: filterType,
            displayKey: "Domain",
            displayValue: filterValue,
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchDomains() {
        var domainsPromise = GlobalFilterService.getDomains(FilterStore.getState());
        var urlsPromise = GlobalFilterService.getUrlFilterTopUrls(FilterStore.getState());

        let [domains, urls] = await Promise.all([domainsPromise, urlsPromise]);

        this.setState({
            availableDomains: domains,
            topUrls: urls,
            availableDomainsLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }
}