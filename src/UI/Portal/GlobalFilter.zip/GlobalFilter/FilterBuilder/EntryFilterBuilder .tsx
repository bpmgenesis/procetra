import * as React from "react";
import { AdditionalFilter, FilterStore } from "../FilterStore";
import { GlobalFilterService } from "../GlobalFilterService";
import { RecentlyViewed } from "../RecentlyViewed";
import { SelectedFilterBuilderTab } from "../FilterBuilder";
import { RefObject } from "react";
import { FilterKindIcon } from "../FilterKindIcon";
import { appliedFilterSort } from "./appliedFilterSort";

export interface EntryFilterBuilderState {
    topPlatforms: { Key: string, Value: number, DisplayName: string }[]
    topEntries: { Key: string, Value: number, DisplayName: string }[]
    entriesLoading: boolean
}

interface EntryFilterBuilderProps {
    additionalFilters: AdditionalFilter[];
    isVisible: boolean;
}

export class EntryFilterBuilder extends React.PureComponent<EntryFilterBuilderProps, EntryFilterBuilderState> {

    constructor(props: EntryFilterBuilderProps) {
        super(props);
        this.state = {
            topPlatforms: null,
            topEntries: null,
            entriesLoading: false
        }
    }

    componentDidUpdate(prevProps: EntryFilterBuilderProps) {
        if (!prevProps.isVisible && this.props.isVisible && !this.state.entriesLoading) {
            this.setState({ entriesLoading: true });
            this.fetchTopEntries();
        }
    }

    render() {
        var entryFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Entry).filter(x => x.type === "entry");
        var platformFilters = FilterStore.getProposedFilters(SelectedFilterBuilderTab.Entry).filter(x => x.type === "platform");
        var topEntries = this.renderTopEntries();
        var topPlatforms = this.renderTopPlatforms();
        var noQuickFilters = null;
        if (topEntries == null && topPlatforms === null) {
            noQuickFilters = <h4 className="no-quick-filters">Sorry, there are no entries or platforms available</h4>;
        }
        return (
            <div className="tab-filter-builder flex" style={{
                display: this.props.isVisible ? "flex" : "none"
            }}>
                <div className="applied-filters">
                    <div style={{ minHeight: "227px" }}>
                        <h4>Entry Filters</h4>
                        <hr />
                        {this.renderEntryFilters(entryFilters)}
                    </div>
                    <div>
                        <h4 style={{ marginTop: "20px" }}>Platform Filters</h4>
                        <hr />
                        {this.renderPlatformFilters(platformFilters)}
                    </div>
                </div>
                <div className="quick-filters">
                    {topEntries}
                    {topPlatforms}
                    {noQuickFilters}
                </div>
            </div>
        )
    }

    renderEntryFilters(entryFilters: AdditionalFilter[]) {
        if (!entryFilters || entryFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Entry Filters</span>
        }
        entryFilters = entryFilters.sort(appliedFilterSort);

        var renderedEntryFilters = entryFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedEntryFilters;
    }

    renderPlatformFilters(platformFilters: AdditionalFilter[]) {
        if (!platformFilters || platformFilters.length === 0) {
            return <span className="no-filters">No Currently Applied Platform Filters</span>
        }
        platformFilters = platformFilters.sort(appliedFilterSort);

        var renderedPlatformFilters = platformFilters.map((filter, idx) => {
            return (
                <div className="flex filter-item" key={filter.type + filter.rawValue}>
                    {idx !== 0 && !filter.isNegated && <span className="or">or</span>}
                    {idx !== 0 && filter.isNegated && <span className="and">and</span>}
                    <span className="filter-value">
                        <FilterKindIcon filter={filter} />
                        <span className="filter-text" title={filter.displayValue} > {filter.displayValue}</span>
                        <span className="remove-filter" onClick={e => this.deleteFilter(e, filter)}>
                            <i className="fa fa-times-circle"></i>
                        </span>
                    </span>
                </div>
            )
        });

        return renderedPlatformFilters;
    }

    renderTopEntries() {
        var topEntries = (this.state.topEntries || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Entry).find(y => x.Key === y.rawValue));
        topEntries = topEntries.slice(0, 5);
        if (topEntries.length > 0 || this.state.entriesLoading) {
            return (
                <div className="top-filters">
                    <h4>Top Entries <span>Quick Add Common Filters</span></h4>
                    <hr />
                    {this.state.entriesLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.entriesLoading && this.state.topEntries &&
                        topEntries.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "entry", x.Key, x.DisplayName)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.DisplayName}>{x.DisplayName}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this entry source">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "entry", x.Key, x.DisplayName, true)} title="Excludes all errors from this entry source">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    renderTopPlatforms() {
        var topPlatforms = (this.state.topPlatforms || []).filter(x => !FilterStore.getProposedFilters(SelectedFilterBuilderTab.Entry).find(y => x.Key === y.rawValue));
        topPlatforms = topPlatforms.slice(0, 5);
        if (topPlatforms.length > 0 || this.state.entriesLoading) {
            return (
                <div className="top-filters" style={{ minHeight: "0" }}>
                    <h4>Platforms <span>Now with Node Support!</span></h4>
                    <hr />
                    {this.state.entriesLoading &&
                        <div className="loading">Loading</div>
                    }
                    {!this.state.entriesLoading && this.state.topPlatforms &&
                        topPlatforms.map(x => {
                            return (
                                <div className="flex filter-item" key={x.Key} onClick={e => this.addFilter(e, "platform", x.Key, x.DisplayName)}>
                                    <span className="filter-value">
                                        <span className="filter-text" title={x.DisplayName}>{x.DisplayName}</span>
                                        <span className="result-count">{x.Value.toLocaleString()}</span>
                                        <span className="add-filter" title="Includes all errors from this platform">
                                            <i className="fa fa-plus-circle"></i>
                                        </span>
                                        <span className="negate-filter" onClick={e => this.addFilter(e, "platform", x.Key, x.DisplayName, true)} title="Excludes all errors from this platform">
                                            <i className="fa fa-minus-circle"></i>
                                        </span>
                                    </span>
                                </div>
                            )
                        })
                    }
                </div>
            );
        }
        else {
            return null;
        }
    }

    addFilter(evt, filterType: string, filterValue: string, displayValue: string, isNegated = false): any {
        evt.stopPropagation();
        var additionalFilter: AdditionalFilter = {
            type: filterType,
            displayKey: "Entry",
            displayValue: displayValue,
            rawValue: filterValue,
            isNegated: isNegated
        }
        FilterStore.addFilter(additionalFilter);
    }

    async fetchTopEntries() {
        var { topEntries, topPlatforms } = await GlobalFilterService.getTopEntriesAndPlatforms(FilterStore.getState());
        this.setState({
            topEntries: topEntries,
            topPlatforms: topPlatforms,
            entriesLoading: false
        });
    }

    deleteFilter(evt, filter) {
        FilterStore.removeFilter(filter);
    }
}